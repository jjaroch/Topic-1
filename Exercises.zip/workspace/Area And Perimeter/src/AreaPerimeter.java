
public class AreaPerimeter {
	public static void main(String[] args) {
		 
		  System.out.println("Radius of circle = 5.5");
		  System.out.println("Perimeter = 2 x radius x pi = " + 2 * 5.5 * Math.PI);
		  System.out.println("Area = radius x radius x pi = " + 5.5 * 5.5
		    * Math.PI);
		 
		 }
		}

