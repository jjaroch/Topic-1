
public class MyLinkedList {

}
