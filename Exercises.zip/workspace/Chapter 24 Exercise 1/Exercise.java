
public class Exercise {

}
